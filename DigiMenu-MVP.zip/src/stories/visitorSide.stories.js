import React from 'react';
import MenuDisplay from '../comps/VisitorSideView/MenuDisplay/index';
//import {action} from '@storybook/addon-actions';

export default {
  title: 'VisitorSide',
  component: MenuDisplay,
};

export const MainMenuDisplay = () => {
  return <MenuDisplay />;
}

