import React from 'react';
import ImageUploader from '../comps/addItem/imageUploader/index';
//import {action} from '@storybook/addon-actions';

export default {
  title: 'ImageUploader',
  component: ImageUploader,
};

export const MainImageUploader = () => {
  return <ImageUploader />;
}

