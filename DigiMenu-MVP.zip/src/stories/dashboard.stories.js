import React from 'react';
import Dashboard from '../comps/dashboard/index';
//import {action} from '@storybook/addon-actions';

export default {
  title: 'Dashboard',
  component: Dashboard,
};

export const dashboard = () => {
  return <Dashboard />;
}

